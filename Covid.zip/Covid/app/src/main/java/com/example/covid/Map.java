package com.example.covid;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;


public class Map extends View {
    private static AlertDialog.Builder alertDialog;

    public Map(Context context) {
        super(context);
        setFocusableInTouchMode(true);

        alertDialog = new AlertDialog.Builder(context)
                .setIcon(android.R.drawable.ic_dialog_info)
                .setMessage("Score: " + score);
    }

    String[][] map = new String[7][8];
    int pinknumber = 5;
    int greennumber = 5;
    int totalSecs = 120;
    int seconds;
    float xplayer = 938;
    float yplayer = 1340;
    int xp = 6;
    int yp = 6;
    boolean flag = true;
    int score = 0;
    int spray = 10;


    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        totalSecs--;

        super.onDraw(canvas);

        Paint paintRectangle = new Paint();

        paintRectangle.setColor(Color.parseColor("#A9A9A9"));
        paintRectangle.setStyle(Paint.Style.STROKE);
        paintRectangle.setStrokeWidth(26);

        canvas.drawRect(0, 0, 1080, 210, paintRectangle);

        Bitmap bar = BitmapFactory.decodeResource(getResources(), R.drawable.bar);
        canvas.drawBitmap(bar, 10, 10, new Paint());

        Bitmap sprayy = BitmapFactory.decodeResource(getResources(), R.drawable.spray);
        canvas.drawBitmap(sprayy, 930, 1520, new Paint());

        map[xp][yp] = "player";
        map[6][7] = "spray";

        int xrandom;
        int yrandom;

        if (flag) {

            map[1][1] = "block";
            map[2][1] = "block";
            map[3][1] = "block";
            map[4][1] = "block";
            map[5][1] = "block";
            map[1][2] = "block";
            map[1][3] = "block";
            map[1][4] = "block";
            map[1][5] = "block";
            map[5][3] = "block";
            map[5][4] = "block";
            map[5][5] = "block";
            map[2][7] = "block";
            map[3][7] = "block";
            map[4][7] = "block";

            int n = 0;
            while (n < 5) {
                xrandom = new Random().nextInt(7);
                yrandom = new Random().nextInt(6);
                if (map[xrandom][yrandom] == null) {
                    map[xrandom][yrandom] = "green";
                    n++;
                }
            }

            n = 0;
            while (n < 5) {
                xrandom = new Random().nextInt(7);
                yrandom = new Random().nextInt(6);
                if (map[xrandom][yrandom] == null) {
                    map[xrandom][yrandom] = "pink";
                    n++;
                }
            }
        }

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 8; j++) {

                if (map[i][j] == "green") {
                    Bitmap greenVirus = BitmapFactory.decodeResource(getResources(), R.drawable.greenvirus);
                    canvas.drawBitmap(greenVirus, i * 153 + 15, j * 180 + 260, new Paint());
                } else if (map[i][j] == "pink") {
                    Bitmap pinkVirus = BitmapFactory.decodeResource(getResources(), R.drawable.pinkvirus);
                    canvas.drawBitmap(pinkVirus, i * 153 + 15, j * 180 + 260, new Paint());
                } else if (map[i][j] == "block") {
                    Bitmap block = BitmapFactory.decodeResource(getResources(), R.drawable.block);
                    canvas.drawBitmap(block, i * 153 + 15, j * 180 + 260, new Paint());
                }
            }
        }

        float x = 5;
        float y = 250;
        Paint paintline = new Paint();
        paintline.setStrokeWidth(5);

        for (int i = 0; i <= 8; i++) {
            canvas.drawLine(x, y, x + 1070, y, paintline);
            y += 180;
        }

        y = 250;
        for (int i = 0; i <= 7; i++) {
            canvas.drawLine(x, y, x, y + 1440, paintline);
            x += 153;
        }

        Bitmap player = BitmapFactory.decodeResource(getResources(), R.drawable.player);
        canvas.drawBitmap(player, xplayer, yplayer, new Paint());

        flag = false;
        Paint textpaint = new Paint();
        textpaint.setTextSize(60);
        textpaint.setColor(Color.rgb(255, 255, 0));
        canvas.drawText("Score: " + String.valueOf(score), 25, 130, textpaint);


        if (totalSecs > 0) {
            int minutes = (totalSecs % 3600) / 60;
            seconds = totalSecs % 60;
            Paint timerpaint = new Paint();
            timerpaint.setTextSize(60);
            timerpaint.setColor(Color.rgb(255, 255, 0));
            canvas.drawText("Time: " + String.valueOf(minutes) + " : " + String.valueOf(seconds), 360, 130, timerpaint);
        } else if (totalSecs == 0) {
            Paint timerpaint = new Paint();
            timerpaint.setTextSize(60);
            timerpaint.setColor(Color.rgb(255, 255, 0));
            canvas.drawText("Time: " + " 0 : 00 ", 360, 130, timerpaint);

        }


        Paint spraypaint = new Paint();
        spraypaint.setTextSize(60);
        spraypaint.setColor(Color.rgb(255, 255, 0));
        canvas.drawText(": " + String.valueOf(spray), 940, 130, spraypaint);

        invalidate();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (event.getAction() == MotionEvent.ACTION_DOWN) {

            int y = (int) Math.abs(event.getY() - yplayer);
            // left
            if (event.getX() < xplayer && y < 100 && xplayer > 50 && xp < 7 && xp >= 1
                    && yp < 8 && yp >= 0) {

                if (map[xp - 1][yp] == "block") {
                    map[xp][yp] = "player";
                } else if (map[xp - 1][yp] == "green") {
                    if (spray >= 2) {
                        xplayer -= 154;
                        map[xp][yp] = null;
                        xp--;
                        map[xp][yp] = "player";
                        spray -= 2;
                        greennumber--;
                        score += 10;

                    } else if (score >= 10) {
                        xplayer -= 154;
                        map[xp][yp] = null;
                        xp--;
                        map[xp][yp] = "player";
                        greennumber--;
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else if (map[xp - 1][yp] == "pink") {
                    if (spray >= 4) {
                        xplayer -= 154;
                        map[xp][yp] = null;
                        xp--;
                        map[xp][yp] = "player";
                        spray -= 4;
                        pinknumber--;
                        score += 20;

                    } else if (score >= 10) {
                        xplayer -= 154;
                        map[xp][yp] = null;
                        xp--;
                        pinknumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else {
                    xplayer -= 154;
                    map[xp][yp] = null;
                    xp--;
                    map[xp][yp] = "player";
                }
            }
            // right
            else if (event.getX() > xplayer && y < 100 && xplayer < 940 && xp < 6 && xp >= 0
                    && yp < 8 && yp >= 0) {

                if (map[xp + 1][yp] == "block") {
                    map[xp][yp] = "player";
                } else if (map[xp + 1][yp] == "green") {
                    if (spray >= 2) {
                        xplayer += 154;
                        map[xp][yp] = null;
                        xp++;
                        greennumber--;
                        map[xp][yp] = "player";
                        spray -= 2;
                        score += 10;

                    } else if (score >= 10) {
                        xplayer += 154;
                        map[xp][yp] = null;
                        xp++;
                        greennumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else if (map[xp + 1][yp] == "pink") {
                    if (spray >= 4) {
                        xplayer += 154;
                        map[xp][yp] = null;
                        xp++;
                        pinknumber--;
                        map[xp][yp] = "player";
                        spray -= 4;
                        score += 20;

                    } else if (score >= 10) {
                        xplayer += 154;
                        map[xp][yp] = null;
                        xp++;
                        pinknumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else if (map[xp + 1][yp] == "spray") {
                    xplayer += 154;
                    xp++;
                    map[xp][yp] = "player";
                    spray = 12;
                } else {
                    xplayer += 154;
                    map[xp][yp] = null;
                    xp++;
                    map[xp][yp] = "player";
                }
            }
            // up
            else if (event.getY() < yplayer && yplayer > 300 && xp < 7 && xp >= 0
                    && yp < 8 && yp >= 0) {

                if (map[xp][yp - 1] == "block") {
                    map[xp][yp] = "player";
                } else if (map[xp][yp - 1] == "green") {
                    if (spray >= 2) {
                        yplayer -= 178;
                        map[xp][yp] = null;
                        yp--;
                        greennumber--;
                        map[xp][yp] = "player";
                        spray -= 2;
                        score += 10;
                    } else if (score >= 10) {
                        yplayer -= 178;
                        map[xp][yp] = null;
                        yp--;
                        greennumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else if (map[xp][yp - 1] == "pink") {
                    if (spray >= 4) {
                        yplayer -= 178;
                        map[xp][yp] = null;
                        yp--;
                        pinknumber--;
                        map[xp][yp] = "player";
                        spray -= 4;
                        score += 20;
                    } else if (score >= 10) {
                        yplayer -= 178;
                        map[xp][yp] = null;
                        yp--;
                        pinknumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else {
                    yplayer -= 178;
                    map[xp][yp] = null;
                    yp--;
                    map[xp][yp] = "player";
                }
            }
            // down
            else if (event.getY() > yplayer && yplayer < 1518 && xp < 7 && xp >= 0
                    && yp < 7 && yp >= 0) {

                if (map[xp][yp + 1] == "block") {
                    map[xp][yp] = "player";
                } else if (map[xp][yp + 1] == "green") {
                    if (spray >= 2) {
                        yplayer += 178;
                        map[xp][yp] = null;
                        yp++;
                        greennumber--;
                        map[xp][yp] = "player";
                        spray -= 2;
                        score += 10;
                    } else if (score >= 10) {
                        yplayer += 178;
                        map[xp][yp] = null;
                        yp++;
                        greennumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else if (map[xp][yp + 1] == "pink") {
                    if (spray >= 4) {
                        yplayer += 178;
                        map[xp][yp] = null;
                        yp++;
                        pinknumber--;
                        map[xp][yp] = "player";
                        spray -= 4;
                        score += 20;
                    } else if (score >= 10) {
                        yplayer += 178;
                        map[xp][yp] = null;
                        yp++;
                        pinknumber--;
                        map[xp][yp] = "player";
                        score -= 10;
                    } else if (score < 10) {
                        score = -1000;
                    }

                } else if (map[xp][yp + 1] == "spray") {
                    yplayer += 178;
                    yp++;
                    map[xp][yp] = "player";
                    spray = 12;
                } else {
                    yplayer += 178;
                    map[xp][yp] = null;
                    yp++;
                    map[xp][yp] = "player";
                }
            }

            if (score == -1000) {
                alertDialog.setTitle("Game Over!").create().show();
            } else if (totalSecs < 0 || seconds < 0) {
                alertDialog.setTitle("Game Over!").create().show();
            } else if (pinknumber == 0 && greennumber == 0) {
                alertDialog.setTitle("You Won!").create().show();
            }
            invalidate();

        }

        return super.onTouchEvent(event);
    }
}

